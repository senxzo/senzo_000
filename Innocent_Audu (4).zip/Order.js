module.exports = class Order {
  constructor() {
    this.done = false;
    this.menu = ["1. shawarma ($10)", "2. Pizza ($10)", "3. Burger ($10)"];
  }
  isDone(done) {
    if (done) {
      response = {
        message: orders,
      };
    }
    return this.done;
  }
  getOrderSummary() {
    let summary = ` :item- ${this.item}, size - ${this.size}, Toppings - ${this.topping}`;

    return summary;
  }
};
