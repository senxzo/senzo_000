const express = require("express");
const bodyParser = require("body-parser");
const Order = require("./Order");
const CakeProcess = require("./CakeProcess");
const Shawarma = require("./Shawarma");
const Pizza = require("./Pizza");
const Burger = require("./Burger");

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());

app.use(express.static("www"));

const OrderState = Object.freeze({
  WELCOME: Symbol(0),
  BURGER: Symbol(1),
  TOPPINGS: Symbol(2),
  QUERY: Symbol(10),
  DRINKS: Symbol(3),
  SHAWARMA: Symbol(4),
  SHWTOPPING: Symbol(6),
  PIZZA: Symbol(7),
  PIZZATOPPING: Symbol(9),
  RESP: Symbol(10),
  UPSELL: Symbol(11),
  BURGERTOPPINGS: Symbol(5),
  ITEMS: Symbol(12),
  QSET: Symbol(13),
});

const cakeOrder = new CakeProcess();
let shawarma = new Shawarma();
let pizza = new Pizza();
const order = new Order();
let burger = new Burger();
let orders = "";
let currentState = OrderState.WELCOME;
const maxOrder = 2;
let orderCount = 0;
let orderList = [];

app.post("/chat", (req, res) => {
  const reply = req.body.message.toLowerCase();
  let response;

  // Process the user's message based on the current order state
  switch (currentState) {
    case OrderState.WELCOME:
      currentState = OrderState.RESP;
      response = {
        message:
          "Welcome to Innocent Audu pastry ordering service! (Enter 1, 2, or 3 to select)",
        options: order.menu,
      };
      break;
    case OrderState.RESP:
      if (orderCount + 1 == maxOrder && (reply === "no" || reply === "n")) {
        currentState = OrderState.UPSELL;
        response = {
          message:
            "Would you like to add a cake or drink to your order @ $5 only? (Yes/No)",
        };
        break;
      } else {
        if (reply === "1") {
          currentState = OrderState.SHAWARMA;
          orderCount++;
          response = {
            message: "Select your shawarma size",
            options: shawarma.sizeOptions,
          };
          break;
        } else if (reply === "2") {
          currentState = OrderState.PIZZA;
          orderCount++;
          response = {
            message: "Select your pizza size",
            options: pizza.sizeOptions,
          };
          break;
        } else if (reply === "3") {
          currentState = OrderState.BURGER;
          orderCount++;
          response = {
            message: "Select a burger size",
            options: burger.sizeOptions,
          };
          break;
        } else {
          currentState = OrderState.WELCOME;
          response = {
            message: "Invalid Entry. Enter any key then send to continue",
          };
          break;
        }
      }

    case OrderState.SHAWARMA:
      currentState = OrderState.SHWTOPPING;
      orderList.push(new Shawarma(true, reply));
      response = {
        message: "Please choose your toppings.",
        options: shawarma.toppingOptions,
      };
      break;

    case OrderState.SHWTOPPING:
      if (orderCount >= maxOrder) {
        orderList[orderCount - 1].addTopping(reply);
        currentState = OrderState.UPSELL;
        response = {
          message:
            "Would you like to add a cake or drink to your order @ $5 only? (Yes/No)",
        };
      } else {
        currentState = OrderState.RESP;
        orderList[orderCount - 1].addTopping(reply);
        response = {
          message: "Do add another item (enter No if none) ?",
          options: order.menu,
        };
      }
      break;
    case OrderState.UPSELL:
      if (reply == "yes") {
        currentState = OrderState.QUERY;
        response = { message: "Enter 1 for drink and 2 for cakes" };
        break;
      } else {
        currentState = OrderState.WELCOME;
        response = {
          message: "\n\n" + print(),
        };
      }
      break;

    case OrderState.QUERY:
      if (reply == 1) {
        currentState = OrderState.DRINKS;
        response = {
          message: "Select a drink",
          options: cakeOrder.drinkOptions,
        };
        break;
      } else if (reply == 2) {
        currentState = OrderState.TOPPINGS;
        response = {
          message: "Select your cake type:",
          options: cakeOrder.toppingOptions,
        };
        break;
      } else {
        currentState = OrderState.SHWTOPPING;
        response = {
          message: "invalid entry, press any key then send to continue",
        };
      }
      break;

    case OrderState.DRINKS:
      currentState = OrderState.WELCOME;
      cakeOrder.setDrink(reply);
      cakeOrder.isSelected = true;
      response = {
        message: "\n\n" + print(),
      };
      break;

    case OrderState.TOPPINGS:
      currentState = OrderState.WELCOME;
      cakeOrder.isSelected = true;
      cakeOrder.addTopping(reply);
      response = {
        message: "\n\n" + print(),
      };
      break;

    case OrderState.PIZZA:
      currentState = OrderState.PIZZATOPPING;
      orderList.push(new Pizza(true, reply));
      response = {
        message: "Please choose your toppings.",
        options: pizza.toppingOptions,
      };
      break;

    case OrderState.PIZZATOPPING:
      if (orderCount >= maxOrder) {
        orderList[orderCount - 1].addTopping(reply);
        currentState = OrderState.UPSELL;
        response = {
          message:
            "Would you like to add a cake or drink to your order @ $5 only? (Yes/No)",
        };
      } else {
        currentState = OrderState.RESP;
        orderList[orderCount - 1].addTopping(reply);
        response = {
          message: "Do add another item (enter No if none) ?",
          options: order.menu,
        };
      }
      break;

    case OrderState.BURGER:
      currentState = OrderState.BURGERTOPPINGS;
      orderList.push(new Burger(true, reply));
      response = {
        message: "Please choose your burger toppings/option.",
        options: burger.toppingOptions,
      };
      break;

    case OrderState.BURGERTOPPINGS:
      if (orderCount >= maxOrder) {
        orderList[orderCount - 1].addTopping(reply);
        currentState = OrderState.UPSELL;
        response = {
          message:
            "Would you like to add a cake or drink to your order @ $5 only? (Yes/No)",
        };
      } else {
        currentState = OrderState.RESP;
        orderList[orderCount - 1].addTopping(reply);
        response = {
          message: "Do add another item (enter No if none) ?",
          options: order.menu,
        };
      }
      break;

    default:
      currentState = OrderState.WELCOME;
      response = {
        message: "Sorry, I didn't understand. Let's restart your order!",
      };
      break;
  }

  function print() {
    let pickupTime = new Date();
    pickupTime.setMinutes(pickupTime.getMinutes() + 20);
    let itemPrice = 0;

    if (cakeOrder.isSelected) {
      itemPrice += 5;
      orders += cakeOrder.getOrderSummary() + "\n";
    }

    for (o of orderList) {
      itemPrice += 10;
      orders += o.getOrderSummary() + "\n";
    }

    let total = itemPrice * 1.13;

    order.done = true;
    orderCount = 0;
    orders =
      "Thank you. " +
      "\nSub Total is: $" +
      itemPrice.toFixed(2) +
      "\nTotal (13% tax) is: " +
      "$" +
      total.toFixed(2) +
      "\nPick up your order by: " +
      pickupTime +
      "\nHere is the order summary: " +
      orders;

    if (order.isDone()) {
      const temp = orders;
      orders = "";
      orderList = [];
      return temp;
    }
  }

  res.json({ response });
});

app.listen(3002, () => {
  console.log("listening on port 3002");
});
